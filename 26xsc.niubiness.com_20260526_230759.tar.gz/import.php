<?php
// 数据库配置
$host = '127.0.0.1';
$db   = '26xsc_niubiness_';
$user = '26xsc_niubiness_';
$pass = '5T6naCsejJXpnpSD';
$charset = 'utf8mb4';

// 连接数据库
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("数据库连接失败: " . $conn->connect_error);
}
$conn->set_charset($charset);

// CSV 文件路径（请确认路径正确）
$csvFile = __DIR__ . '/private.csv';   // 放在当前 PHP 文件同一目录下

if (!file_exists($csvFile)) {
    die("CSV 文件不存在: " . $csvFile);
}

// 打开 CSV 文件
$handle = fopen($csvFile, 'r');
if ($handle === false) {
    die("无法打开 CSV 文件");
}

// 读取第一行标题（跳过）
$header = fgetcsv($handle, 0, ',', '"', '\\');
if ($header === false) {
    die("CSV 文件为空");
}

// 预处理插入语句（不包含自增 id）
$sql = "INSERT INTO private_school (
    school_name, lottery_method, 
    signup_2025, admit_2025, lottery_rate_2025,
    signup_2024, admit_2024, lottery_rate_2024,
    plan_2025, plan_2024, enrollment_2023,
    contact_phone, direct_admission_note, special_class_note,
    exam_2026_info, exam_2025_info, tuition_per_semester, remark
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("预处理失败: " . $conn->error);
}

/**
 * 将百分比字符串（如"11.31%"）转换为 DECIMAL(5,4) 数值
 * 如果遇到"直接录取"或空字符串，返回 NULL
 */
function parsePercentage($value) {
    $value = trim($value);
    if ($value === '' || $value === '直接录取') {
        return null;
    }
    if (strpos($value, '%') !== false) {
        $num = (float) str_replace('%', '', $value);
        return round($num / 100, 4);
    }
    // 如果是纯数字（如0.1291），直接返回
    return is_numeric($value) ? (float) $value : null;
}

/**
 * 将字符串转换为整数，空值返回 NULL
 */
function parseIntOrNull($value) {
    $value = trim($value);
    if ($value === '' || $value === '直接录取') {
        return null;
    }
    // 去除可能的空格、逗号（如"1,768" -> 1768）
    $value = str_replace(',', '', $value);
    return is_numeric($value) ? (int) $value : null;
}

$successCount = 0;
$errorCount = 0;

while (($data = fgetcsv($handle, 0, ',', '"', '\\')) !== false) {
    // CSV 列索引（共18列，索引0~17）
    // 0:学校名称,1:摇号方式,2:2025报名人数,3:2025录取人数,4:2025摇号率,
    // 5:2024报名人数,6:2024录取人数,7:2024摇号率,8:2025招生计划,9:2024招生计划,
    // 10:2023招生数,11:招生咨询电话,12:直升情况,13:特殊班型备注,
    // 14:2026中考情况,15:2025中考情况,16:学费/学期,17:备注
    if (count($data) < 18) {
        // 如果某行字段不足，跳过
        $errorCount++;
        continue;
    }

    $school_name   = trim($data[0]);
    $lottery_method= trim($data[1]);
    
    $signup_2025   = parseIntOrNull($data[2]);
    $admit_2025    = parseIntOrNull($data[3]);
    $lottery_rate_2025 = parsePercentage($data[4]);
    
    $signup_2024   = parseIntOrNull($data[5]);
    $admit_2024    = parseIntOrNull($data[6]);
    $lottery_rate_2024 = parsePercentage($data[7]);
    
    $plan_2025     = parseIntOrNull($data[8]);
    $plan_2024     = parseIntOrNull($data[9]);
    $enrollment_2023 = parseIntOrNull($data[10]);
    
    $contact_phone = trim($data[11]);
    $direct_admission_note = trim($data[12]);
    $special_class_note = trim($data[13]);
    $exam_2026_info = trim($data[14]);
    $exam_2025_info = trim($data[15]);
    $tuition_per_semester = trim($data[16]);
    $remark = trim($data[17]);

    // 绑定参数（注意类型：除数字外都是字符串，数字用字符串绑定也可以）
    $stmt->bind_param(
        'ssiidiiiiissssssss',
        $school_name, $lottery_method,
        $signup_2025, $admit_2025, $lottery_rate_2025,
        $signup_2024, $admit_2024, $lottery_rate_2024,
        $plan_2025, $plan_2024, $enrollment_2023,
        $contact_phone, $direct_admission_note, $special_class_note,
        $exam_2026_info, $exam_2025_info, $tuition_per_semester, $remark
    );

    if ($stmt->execute()) {
        $successCount++;
    } else {
        echo "插入失败: " . $stmt->error . " 学校: " . $school_name . "\n";
        $errorCount++;
    }
}

fclose($handle);
$stmt->close();
$conn->close();

echo "导入完成。成功: {$successCount} 条，失败: {$errorCount} 条。\n";
?>